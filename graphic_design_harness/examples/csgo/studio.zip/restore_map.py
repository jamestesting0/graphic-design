import hashlib
from pathlib import Path
from urllib.request import urlopen


ROOT = Path(__file__).resolve().parent
URL = "https://cdn.fastly.steamstatic.com/apps/csgo/images/dust2/screens/shot4a.jpg"
EXPECTED = "7ae8328816e5e8388ecea0ab801a459eaae07117899c6e16074a0ea43b8e8017"


def main():
    locations = [ROOT / line for line in (ROOT / "map-locations.txt").read_text().splitlines()]
    for path in locations:
        if not path.resolve().is_relative_to(ROOT) or path.name != "dust-ii.jpg":
            raise SystemExit(f"Unexpected asset location: {path}")
        if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest() != EXPECTED:
            raise SystemExit(f"Keep the existing edit in {path}; move it aside to restore.")
    missing = [path for path in locations if not path.exists()]
    if missing:
        with urlopen(URL, timeout=30) as source:
            data = source.read()
        if hashlib.sha256(data).hexdigest() != EXPECTED:
            raise SystemExit("Valve’s source differs from the reviewed original.")
        for path in missing:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
    print(f"Map verified at {len(locations)} project locations.")


if __name__ == "__main__":
    main()
