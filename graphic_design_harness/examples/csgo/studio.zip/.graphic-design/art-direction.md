# After Hours Cup art direction

Three Discord posts for a friendly CS:GO match with the precision of a small tournament broadcast. First read event title, then date, time and host on the poster. Matchup reads opponents at equal weight. Winner reads champion, exact result and losing opponent. Confirmed facts are Friday 27 November 2026, 8 pm Berlin time, Northline against Side Street. Side Street 2–1 is an example result.

The native attachment is 1600 × 900, with a 399 px-wide dark-mode Discord screenshot composite for judging its common use-size. No private-channel screenshot was supplied. The borrowed chrome is a local existing Discord screenshot. It determines attachment scale and surrounding contrast.

Compare A's fluorescent nightlife broadcast over a CS:GO scene against B's red-and-cream printed ticket with numbered-match character coming from old sports ephemera and an original trophy. A reads like a broadcast and uses the actual game environment. B makes the invite feel like admission to a small live event and works without borrowed art. Use the poster to settle the whole family. Asset source and roles are in the library.
