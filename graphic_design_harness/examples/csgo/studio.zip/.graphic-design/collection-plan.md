# Collection plan

My friends and I are having a CS:GO night. Could you make a poster for Discord, a card showing who’s playing, and one for the winner? I want it to feel like a real tournament. Show me a couple of ideas and I’ll pick.

## Deliverables, order and dependencies

1. Poster first. Compare equal-format rendered compositions A and B and let the client decide which promise fits the evening. Then refine bounded issues in the selected direction.
2. Matchup after direction. Draw two equivalent team areas with the names taking priority. Keep any eventual client badge as a separate component.
3. Winner in the same direction with a changed hierarchy. Side Street gets the spotlight and the 2–1 outcome remains paired with Northline. The live match has yet to be played.

For each, retain an editable source with linked assets, full PNG and comparable Discord-scale screenshot composite. Inspect native details and preview. Stop on the client's review decision.
