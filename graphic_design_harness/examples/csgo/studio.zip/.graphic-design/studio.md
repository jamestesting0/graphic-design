# Studio board

[Collection plan](collection-plan.md) · [Shared direction](art-direction.md) · [Asset register](library/assets.md)

| Graphic / use | Stage | Work status | Working | Approved | Last delivery | Next decision |
|---|---|---|---|---|---|---|
| [matchup](graphics/matchup/plan.md) / main | composition | awaiting selection | [Pair-03](graphics/matchup/versions/Pair-03/bundle/proof.png) | [Pair-02](graphics/matchup/versions/Pair-02/bundle/proof.png) | [after-hours-v1 · Pair-02](../deliverables/after-hours-v1/manifest.json) | Compare the grouped heading to the delivered Pair-02. |
| [poster](graphics/poster/plan.md) / main | delivery | complete | [Arena-02](graphics/poster/versions/Arena-02/bundle/proof.png) | [Arena-02](graphics/poster/versions/Arena-02/bundle/proof.png) | [after-hours-v1 · Arena-02](../deliverables/after-hours-v1/manifest.json) | Delivered. |
| [winner](graphics/winner/plan.md) / main | delivery | complete | [Result-02](graphics/winner/versions/Result-02/bundle/proof.png) | [Result-02](graphics/winner/versions/Result-02/bundle/proof.png) | [after-hours-v1 · Result-02](../deliverables/after-hours-v1/manifest.json) | Delivered. |

## Study galleries

- [matchup / production](graphics/matchup/studies/production/gallery.md)
- [matchup / spacing](graphics/matchup/studies/spacing/gallery.md)
- [poster / direction](graphics/poster/studies/direction/gallery.md)
- [poster / production](graphics/poster/studies/production/gallery.md)
- [winner / production](graphics/winner/studies/production/gallery.md)
