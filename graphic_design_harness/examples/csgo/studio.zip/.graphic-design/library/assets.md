# Asset register

Add an entry when a supplied, found or studio-created asset enters the commission. Use relative library paths for stored files. A reference can be a source link.

| Asset | Origin and source | Intended use and credit | Graphics and role |
|---|---|---|---|
| [dust-ii.jpg](dust-ii.jpg) | Found. [Valve’s CS:GO Dust II comparison](https://www.counter-strike.net/dust2), [updated middle scene, 2560 × 1600](https://cdn.fastly.steamstatic.com/apps/csgo/images/dust2/screens/shot4a.jpg). | Valve owns the scene. [Steam Subscriber Agreement §2.D](https://store.steampowered.com/subscriber_agreement/#2) allows qualifying noncommercial fan composites, subject to its terms and third-party rights. The raw JPEG and proof-source bundles stay in this local commission. Raw redistribution and commercial use fall outside this handoff. | Selected direction A and the three production graphics. Cropped, color-treated place imagery. |
| [side-street.svg](side-street.svg) | Supplied. Maker was the test organizer, via `graphic_design_harness/examples/csgo/organizer/side-street.svg`. | Organizer permits use and redistribution with this example, as recorded in the organizer’s README. Preserve the file and colors exactly. Other standalone reuse is outside this grant. | Matchup and winner. Exact linked team identity. |
| Discord attachment surround | Supplied workspace reference. `references/discord/02-live-elo-system-banner.png`. | Internal placement comparison. Retain the crop with review proofs only. | All three graphics at attachment size. |
| North marker | Studio-created vector. | Used as a Northline motif for this match. | Matchup, independent decoration next to Northline name. |
| Lightning slashes and ticket trophy | Studio-created vectors. | Editable event decoration. | Shared slashes in the selected series and trophy in retained alternate B. |
