# Poster stages

1. Direction. Render two poster arrangements at 1600 × 900 with the same event information and the same Discord preview size. The client selects which direction establishes the family.
2. Finish. Assemble the background, graphics, headline, schedule and action on independently editable layers. Verify copy at attachment size and native detail, then save a new version linked to its selected parent.
3. Review. Show the exact PNG, context composite and editable bundle. Record objection or approval against that version.
