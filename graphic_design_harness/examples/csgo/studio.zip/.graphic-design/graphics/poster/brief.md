# Poster

Announce the After Hours Cup to friends in Discord. The title should read first, followed by Friday 27 November 2026, 8 pm Berlin time, and the Discord destination. The plain CS:GO name identifies the game. No signup link or channel name was supplied.

Native attachment is 1600 × 900. Review the full image and as a roughly 399 px attachment in the dark Discord reference. Use licensed or original assets consistent with the selected direction. A private prototype may use the attributed Valve reference composition. Keep all copy and image treatment editable.
