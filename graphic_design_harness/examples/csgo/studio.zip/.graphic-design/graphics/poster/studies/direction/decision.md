# Client direction choice

The two PNGs and like-for-like Discord composites were shown before detailed production. The client selected A: “My friends will recognize that street. Keep that look.” A is pinned as the working parent. B is retained in the gallery. The client then supplied Side Street’s exact badge for both team graphics and delegated the other choices. No delivery approval was requested at this fork.
