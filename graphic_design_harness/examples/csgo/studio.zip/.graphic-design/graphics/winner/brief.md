# Winner card

Show a winning Side Street and 2–1 over Northline as the example requested by the client. Distinguish the example from a live result before the event. Make winner identity and score independently editable, and keep the losing team explicit. Use the family palette and idea at 1600 × 900. Review full size and at the Discord attachment size.
