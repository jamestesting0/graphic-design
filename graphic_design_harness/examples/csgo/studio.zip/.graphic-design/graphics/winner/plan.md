# Winner stages

1. Hierarchy study. Give Side Street the biggest name and use readable score order. Test whether somebody seeing the image alone can attribute 2–1 to the right teams.
2. Finish. Separate winner name, score and footer, then verify the example cue and source edits at both full size and 399 px.
3. Review. Save native and destination proofs with linked editable art. Return for client review.
