# Matchup card

Show who is playing. Northline and Side Street are opposing teams, without player handles provided. Both names get equal weight. Include the event name and date/time for a card shared out of context. Reserve a separable team-symbol layer pending a client badge. Use the poster's selected direction at 1600 × 900 and review at native and Discord size.
