# Reproduce the 1600 × 900 PNG

Run `./render.sh .` from this folder. The export uses Chrome with macOS fonts. On another installation set `CHROME` to the Chrome binary path. The SVG has live text in named layers. Keep the `art` folder beside it when that folder is present. Use Impact and Avenir Next for the dark design or Georgia and Avenir Next for the ticket design to preserve the type metrics.

`preview.png` is a desktop Discord screenshot composite with artwork at 400 px wide.
