#!/bin/sh
set -eu

bundle=$(cd "$1" && pwd)
chrome=${CHROME:-/Applications/Google Chrome.app/Contents/MacOS/Google Chrome}
profile=$(mktemp -d /tmp/after-hours-chrome.XXXXXX)
trap 'rm -rf "$profile"' EXIT

"$chrome" --headless --no-first-run --hide-scrollbars --force-device-scale-factor=1 \
  --allow-file-access-from-files --user-data-dir="$profile" --window-size=1600,900 \
  --screenshot="$bundle/proof.png" "file://$bundle/master.svg"
