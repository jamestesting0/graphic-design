# Matchup stages

1. Hierarchy study. Show Northline and Side Street at equal scale with unmistakable opposition; separate emblems from the live names. Use the shared poster direction.
2. Finish. Inspect spacing with the longer name Side Street and check that the date/time remains readable at the attachment width. Exercise the emblem and name as independently editable components.
3. Review. Save native and destination proofs with the source and inspect the exact export. Return for client review.
