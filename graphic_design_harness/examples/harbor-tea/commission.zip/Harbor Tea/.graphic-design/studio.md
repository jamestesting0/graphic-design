# Studio board

[Collection plan](collection-plan.md) · [Shared direction](art-direction.md)

| Graphic / use | Stage | Work status | Working | Approved | Last delivery | Next decision |
|---|---|---|---|---|---|---|
| [reveal](graphics/reveal/plan.md) / main | delivery | complete | [A](graphics/reveal/versions/A/bundle/proof.png) | [A](graphics/reveal/versions/A/bundle/proof.png) | [launch-v1 · A](../deliverables/launch-v1/manifest.json) | Delivered. |
| [shelf-card](graphics/shelf-card/plan.md) / main | delivery | complete | [B](graphics/shelf-card/versions/B/bundle/proof.png) | [B](graphics/shelf-card/versions/B/bundle/proof.png) | [launch-v1 · B](../deliverables/launch-v1/manifest.json) | Delivered. |
| [social](graphics/social/plan.md) / main | delivery | complete | [A](graphics/social/versions/A/bundle/proof.png) | [A](graphics/social/versions/A/bundle/proof.png) | [launch-v1 · A](../deliverables/launch-v1/manifest.json) | Delivered. |

## Study galleries

- [reveal / hierarchy](graphics/reveal/studies/hierarchy/gallery.md)
- [shelf-card / hierarchy](graphics/shelf-card/studies/hierarchy/gallery.md)
- [social / hierarchy](graphics/social/studies/hierarchy/gallery.md)
