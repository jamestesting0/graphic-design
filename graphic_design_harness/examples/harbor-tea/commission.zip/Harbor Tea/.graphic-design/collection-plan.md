# Collection plan

Introduce Harbor Tea and its jasmine green tea across a shelf card, social tile and six-second reveal.

## Deliverables, order and dependencies

Resolve shelf-card hierarchy first, adapt its two lines to the tile, then lock picture timing for the reveal. Inspect the three together before packaging.
