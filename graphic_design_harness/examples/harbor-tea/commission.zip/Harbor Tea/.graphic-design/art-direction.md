# Shared art direction

Use the original single-line leaf as the family mark. Warm paper #f3eddd and pine ink #1d4039 support a clear two-line hierarchy. Georgia for the name, Arial for the variety. Preserve the natural leaf aspect. No product photo is supplied. No claims about origin or taste are approved.
