# shelf-card

Compare centered and left-aligned names at identical scale. Check trim distance, then name and variety after downsampling.

Exit: inspect the destination proof and record the decisive finding before approval.
