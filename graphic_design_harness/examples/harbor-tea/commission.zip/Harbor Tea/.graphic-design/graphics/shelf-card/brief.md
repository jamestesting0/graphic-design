# shelf-card

Shelf at simulated reading distance. 4 × 6 inches, 300 ppi, 1200 × 1800 px. No bleed requested for this rehearsal.

Sources: shared leaf, original copy and authored color field. Lock the commissioned name and variety.
