# hierarchy

## Latest five

**B (pinned)** · parents: — · Centered lockup

[Master](../../versions/B/bundle/master.svg) · [Proof](../../versions/B/bundle/proof.png)

![B](../../versions/B/bundle/preview.png)

**A (pinned)** · parents: — · Left-aligned lockup

[Master](../../versions/A/bundle/master.svg) · [Proof](../../versions/A/bundle/proof.png)

![A](../../versions/A/bundle/preview.png)
