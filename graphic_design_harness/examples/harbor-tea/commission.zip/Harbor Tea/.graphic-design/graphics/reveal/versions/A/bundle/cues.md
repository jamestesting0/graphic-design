# Reveal timeline

0–4 s: leaf motif over a quiet original A3 tone. At 4.0 s: cut to full wordmark on the E5 accent. 4–6 s: hold the variety; decay and fade to silence. Original synthesized music for this rehearsal. Edit the SVGs, rasterize at 720 px, replace or edit the WAV, and run timeline.sh from the bundle.
