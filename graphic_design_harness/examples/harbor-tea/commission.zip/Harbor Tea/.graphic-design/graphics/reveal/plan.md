# reveal

Block the opening mark, show the lockup at 4 s on the accent, then hold two seconds. Verify sync and decay in the encoded picture and mix.

Exit: inspect the destination proof and record the decisive finding before approval.
