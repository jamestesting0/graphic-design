# reveal

Six seconds, 720 px square, 24 fps. Make the wordmark readable on mute; use an original musical cue.

Sources: shared leaf, original copy and authored color field. Lock the commissioned name and variety.
