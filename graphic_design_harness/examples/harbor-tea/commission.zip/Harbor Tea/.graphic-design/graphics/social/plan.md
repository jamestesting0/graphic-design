# social

Adapt the selected hierarchy to a square. Compare the large mark to the type block. Keep clear air around the variety line.

Exit: inspect the destination proof and record the decisive finding before approval.
