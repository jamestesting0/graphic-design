# social

360 px feed preview of a 720 px square. Both product and variety must read on mobile.

Sources: shared leaf, original copy and authored color field. Lock the commissioned name and variety.
